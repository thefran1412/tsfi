/**
 * Created by nicof on 06/03/2017.
 */
$( document ).ready(function() {
    console.log( document.URL);
});